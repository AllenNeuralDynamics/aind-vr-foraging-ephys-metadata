"""Classes to define reagents"""

from datetime import date
from typing import List, Optional, Union

from biodata_models.organizations import Organization
from biodata_models.pid_names import PIDName
from biodata_models.reagent import FluorophoreType, StainType
from biodata_models.species import Species
from biodata_models.units import MassUnit, SizeUnit
from pydantic import Field

from biodata_schema.base import DataModel, Discriminated


class Fluorophore(DataModel):
    """Flurophore used in HCR, Immunolabeling, etc"""

    fluorophore_type: FluorophoreType = Field(..., title="Fluorophore type")
    excitation_wavelength: int = Field(..., title="Excitation wavelength (nm)")
    excitation_wavelength_unit: SizeUnit = Field(default=SizeUnit.NM, title="Excitation wavelength unit")


class Reagent(DataModel):
    """Description of reagent used in procedure"""

    name: str = Field(..., title="Name")
    source: Organization.ONE_OF = Field(..., title="Source")
    rrid: Optional[PIDName] = Field(default=None, title="Research Resource ID")
    lot_number: Optional[str] = Field(default=None, title="Lot number")
    expiration_date: Optional[date] = Field(default=None, title="Lot expiration date")


class Solution(DataModel):
    """Description of a solution made in house. Should match a solution named in protocol."""

    name: str = Field(..., title="Name")
    lot_number: Optional[str] = Field(default=None, title="Lot number")


class OligoProbe(DataModel):
    """Description of an oligonucleotide probe"""

    name: str = Field(..., title="Name")
    sequence: str = Field(..., title="Sequence")


class GeneProbe(DataModel):
    """Description of a set of oligonucleotide probes targeting a specific gene"""

    gene: PIDName = Field(..., title="Gene name")
    probes: Optional[List[OligoProbe]] = Field(default=None, title="Probes")


class GeneProbeSet(Reagent):
    """set of probes used in BarSEQ"""

    gene_probes: List[GeneProbe] = Field(..., title="Gene probes")


class ProteinProbe(DataModel):
    """Description of a protein probe including antibodies"""

    protein: PIDName = Field(..., title="Target protein name")
    species: Optional[Species.ONE_OF] = Field(default=None, title="Species of the probe")
    mass: float = Field(..., title="Mass of protein probe (ug)")
    mass_unit: MassUnit = Field(default=MassUnit.UG, title="Mass unit")
    sequence: Optional[str] = Field(default=None, title="Amino acid sequence of the probe")


class SmallMoleculeProbe(DataModel):
    """Description of a small molecule probe"""

    molecule: PIDName = Field(..., title="Target small molecule name")
    mass: float = Field(..., title="Mass of small molecule probe (ug)")
    mass_unit: MassUnit = Field(default=MassUnit.UG, title="Mass unit")


class ProbeReagent(Reagent):
    """Description of a probe used as a reagent"""

    target: Union[GeneProbe, ProteinProbe, SmallMoleculeProbe] = Field(..., title="Target")


class FluorescentStain(Reagent):
    """Description of a fluorescent stain consisting of a probe associated with a fluorophore.
    Note this class will change names in v3.0"""

    probe: Discriminated[GeneProbe | ProteinProbe | SmallMoleculeProbe] = Field(..., title="Target of the stain")
    stain_type: StainType = Field(..., title="Stain type")
    fluorophore: Fluorophore = Field(..., title="Fluorophore used in the stain")
    initiator_name: Optional[str] = Field(default=None, title="Initiator for HCR probes")


class FluorescentReagent(Reagent):
    """Description of an inherently fluorescent marker. Note this class will change name in v3.0"""

    stain_type: StainType = Field(..., title="Stain type")
    excitation_wavelength: int = Field(..., title="Excitation wavelength (nm)")
    emission_wavelength: int = Field(..., title="Emission wavelength (nm)")
    wavelength_unit: SizeUnit = Field(default=SizeUnit.NM, title="Excitation wavelength unit")
