"""Surgery procedures components for AIND data schema."""

from enum import Enum
from typing import List, Optional, Union

from biodata_models.anatomy import AnatomyModel
from biodata_models.brain_atlas import BrainStructureModel
from biodata_models.coordinates import AnatomicalRelative
from biodata_models.organizations import Organization
from biodata_models.units import SizeUnit, TimeUnit, VolumeUnit
from pydantic import Field, field_validator, model_validator

from biodata_schema.base import AwareDatetimeWithDefault, DataModel
from biodata_schema.components.configs import CatheterConfig, ProbeConfig
from biodata_schema.components.coordinates import TRANSFORM_TYPES, Translation
from biodata_schema.components.devices import (
    Catheter,
    Device,
    DevicePosition,
    EphysProbe,
    FiberProbe,
    MyomatrixArray,
)
from biodata_schema.components.identifiers import ProtocolMixin
from biodata_schema.components.injection_procedures import Injection


class ProtectiveMaterial(str, Enum):
    """Name of material applied to craniotomy"""

    AGAROSE = "Agarose"
    DURAGEL = "Duragel"
    KWIK_CAST = "Kwik-Cast"
    SORTA_CLEAR = "SORTA-clear"
    OTHER = "Other - see notes"


class SampleType(str, Enum):
    """Sample type"""

    BLOOD = "Blood"
    OTHER = "Other"


class GroundWireMaterial(str, Enum):
    """Ground wire material name"""

    SILVER = "Silver"
    PLATINUM_IRIDIUM = "Platinum iridium"


class CraniotomyType(str, Enum):
    """Name of craniotomy Type"""

    DHC = "Dual hemisphere craniotomy"
    WHC = "Whole hemisphere craniotomy"
    CIRCLE = "Circle"
    SQUARE = "Square"
    OTHER = "Other"


class HeadframeMaterial(str, Enum):
    """Headframe material name"""

    STEEL = "Steel"
    TITANIUM = "Titanium"
    WHITE_ZIRCONIA = "White Zirconia"


class CatheterImplant(DataModel):
    """Description of a catheter implant procedure"""

    where_performed: Organization.ONE_OF = Field(..., title="Where performed")
    implanted_device: Catheter = Field(
        ...,
        title="Implanted device",
    )  # note: exact field name is used by a validator
    device_config: CatheterConfig = Field(
        ...,
        title="Device configuration",
    )  # note: exact field name is used by a validator


class Anaesthetic(DataModel):
    """Description of an anaesthetic"""

    anaesthetic_type: str = Field(..., title="Type")
    duration: float = Field(..., title="Duration")
    duration_unit: TimeUnit = Field(default=TimeUnit.M, title="Duration unit")
    level: Optional[float] = Field(default=None, title="Level (percent)", ge=1, le=5)


class GenericSurgeryProcedure(ProtocolMixin, DataModel):
    """Description of a surgery procedure performed on a subject"""

    description: str = Field(..., title="Description")
    notes: Optional[str] = Field(default=None, title="Notes")


class Craniotomy(ProtocolMixin, DataModel):
    """Description of craniotomy procedure"""

    craniotomy_type: CraniotomyType = Field(..., title="Craniotomy type")

    coordinate_system_name: Optional[str] = Field(default=None, title="Coordinate system name")
    position: Optional[Union[Translation, List[AnatomicalRelative]]] = Field(default=None, title="Craniotomy position")

    size: Optional[float] = Field(default=None, title="Craniotomy size", description="Diameter or side length")
    size_unit: Optional[SizeUnit] = Field(default=None, title="Craniotomy size unit")

    protective_material: Optional[ProtectiveMaterial] = Field(default=None, title="Protective material")
    implant_part_number: Optional[str] = Field(default=None, title="Implant part number")
    dura_removed: Optional[bool] = Field(default=None, title="Dura removed")

    @model_validator(mode="after")
    def check_system_if_position(self):
        """Ensure that coordinate_system_name is provided if position is provided"""

        if self.position and not self.coordinate_system_name:
            raise ValueError("Craniotomy.coordinate_system_name must be provided if Craniotomy.position is provided")
        return self

    @model_validator(mode="after")
    def check_position(self):
        """Ensure a position is provided for certain craniotomy types"""

        POS_REQUIRED = [CraniotomyType.CIRCLE, CraniotomyType.SQUARE, CraniotomyType.WHC]

        if self.craniotomy_type in POS_REQUIRED and not self.position:
            raise ValueError(f"Craniotomy.position must be provided for craniotomy type {self.craniotomy_type}")
        return self

    @model_validator(mode="after")
    def validate_size(self):
        """Ensure that size is provided for certain craniotomy types"""

        SIZE_REQUIRED = [CraniotomyType.CIRCLE, CraniotomyType.SQUARE]

        if self.craniotomy_type in SIZE_REQUIRED and not self.size:
            raise ValueError(f"Craniotomy.size must be provided for craniotomy type {self.craniotomy_type}")
        return self


class DeviceImplant(ProtocolMixin, DevicePosition, DataModel):
    """Description of a generic device implant procedure"""

    implanted_device: Device = Field(
        ...,
        title="Implanted device",
    )  # note: exact field name is used by a validator


class ProbeImplant(ProtocolMixin, DataModel):
    """Description of a probe (fiber, ephys) implant procedure"""

    implanted_device: Union[EphysProbe, FiberProbe] = Field(
        ...,
        title="Implanted device",
    )  # note: exact field name is used by a validator
    device_config: ProbeConfig = Field(
        ...,
        title="Device configuration",
    )  # note: exact field name is used by a validator


class Headframe(ProtocolMixin, DataModel):
    """Description of headframe procedure"""

    headframe_type: str = Field(..., title="Headframe type")
    headframe_part_number: Optional[str] = Field(default=None, title="Headframe part number")
    headframe_material: Optional[HeadframeMaterial] = Field(default=None, title="Headframe material")
    well_part_number: Optional[str] = Field(default=None, title="Well part number")
    well_type: Optional[str] = Field(default=None, title="Well type")


class GroundWireImplant(DataModel):
    """Ground wire implant procedure"""

    ground_electrode_location: AnatomyModel = Field(
        ...,
        title="Location of ground electrode",
        description=(
            "Species-specific anatomy term; use the appropriate lookup (e.g., MouseAnatomyLookup or "
            "HumanAnatomyLookup). For common mouse ground-wire locations, use MouseGroundWireLocations and resolve "
            "the target with MouseAnatomyLookup.get_by_name(...)."
        ),
    )
    ground_wire_hole: Optional[int] = Field(
        default=None, title="Ground wire hole", description="For SHIELD implants, the hole number for the ground wire"
    )
    ground_wire_material: Optional[GroundWireMaterial] = Field(default=None, title="Ground wire material")
    ground_wire_diameter: Optional[float] = Field(default=None, title="Ground wire diameter")
    ground_wire_diameter_unit: Optional[SizeUnit] = Field(default=None, title="Ground wire diameter unit")


class BrainInjection(Injection):
    """Description of an injection procedure into a brain"""

    coordinate_system_name: str = Field(..., title="Coordinate system name")
    coordinates: List[TRANSFORM_TYPES] = Field(..., title="Injection coordinate, depth, and rotation")
    targeted_structure: Optional[BrainStructureModel] = Field(default=None, title="Injection targeted brain structure")

    @model_validator(mode="after")
    def check_lengths(self):
        """Validator for list length of injection volumes and depths"""

        dynamics_len = len(self.dynamics)
        coords_len = len(self.coordinates)

        if dynamics_len != coords_len:
            raise ValueError("Unmatched list sizes for injection volumes and coordinate depths")
        return self


class SampleCollection(DataModel):
    """Description of a single sample collection"""

    sample_type: SampleType = Field(..., title="Sample type")
    time: AwareDatetimeWithDefault = Field(..., title="Collection time")
    collection_volume: float = Field(..., title="Collection volume")
    collection_volume_unit: VolumeUnit = Field(..., title="Collection volume unit")
    collection_method: Optional[str] = Field(default=None, title="Collection method for terminal collection")


class MyomatrixInsertion(ProtocolMixin, DataModel):
    """Description of a Myomatrix array insertion for EMG"""

    ground_electrode: GroundWireImplant = Field(..., title="Ground electrode")

    implanted_device: MyomatrixArray = Field(
        ...,
        title="Implanted device",
    )  # note: exact field name is used by a validator


class Perfusion(ProtocolMixin, DataModel):
    """Description of a perfusion procedure that creates a specimen"""

    output_specimen_names: List[str] = Field(
        ...,
        title="Specimen names",
        description=(
            "Names of specimens resulting from this procedure."
            " Whole brains can use the {subject_name}, partial sections should always include a suffix {subject_name}_###"
        ),
    )

    @field_validator("output_specimen_names", mode="before")
    def validate_output_specimen_names(cls, values: List[str]):
        """Sort specimen names"""
        return sorted(values)
