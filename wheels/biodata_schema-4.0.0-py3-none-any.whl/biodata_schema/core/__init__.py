"""Core schemas"""
